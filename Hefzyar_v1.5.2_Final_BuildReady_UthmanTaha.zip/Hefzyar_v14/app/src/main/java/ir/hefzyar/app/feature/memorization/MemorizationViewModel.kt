package ir.hefzyar.app.feature.memorization

import android.content.Context
import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewModelScope
import ir.hefzyar.app.core.database.HefzyarDatabase
import ir.hefzyar.app.core.database.MemorizationSessionEntity
import ir.hefzyar.app.core.notifications.RetentionScheduler
import ir.hefzyar.app.domain.planning.PlanRepository
import ir.hefzyar.app.domain.memorization.MemorizationState
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch
import java.time.LocalDate

data class MemorizationUiState(
    val stage: MemorizationState = MemorizationState.PREPARING,
    val repetition: Int = 0,
    val errors: Int = 0,
    val finished: Boolean = false
)

class MemorizationViewModel(
    private val context: Context,
    private val db: HefzyarDatabase,
    private val pageStart: Int,
    private val pageEnd: Int,
    private val taskId: Long,
    private val startVerseKey: String = "",
    private val endVerseKey: String = ""
) : ViewModel() {
    private val today = LocalDate.now().toString()
    private var session: MemorizationSessionEntity? = null
    private val planRepository = PlanRepository(db)
    private val _state = MutableStateFlow(MemorizationUiState())
    val state: StateFlow<MemorizationUiState> = _state.asStateFlow()

    init {
        viewModelScope.launch {
            session = db.memorizationSessionDao().observe(today, pageStart, pageEnd).first()
            val s = session
            if (s != null) _state.value = MemorizationUiState(MemorizationState.valueOf(s.stage), s.repetition, s.errors, s.stage == MemorizationState.STABLE.name)
            else save(MemorizationState.PREPARING)
        }
    }

    fun next() {
        viewModelScope.launch {
            val current = _state.value.stage
            val next = when (current) {
                MemorizationState.PREPARING -> MemorizationState.LISTENING
                MemorizationState.LISTENING -> MemorizationState.MEMORIZING
                MemorizationState.MEMORIZING -> if (_state.value.repetition < 3) current else MemorizationState.CONNECTION
                MemorizationState.CONNECTION -> MemorizationState.RETENTION
                MemorizationState.RETENTION -> MemorizationState.REVIEWING
                MemorizationState.REVIEWING -> MemorizationState.STABLE
                MemorizationState.NEEDS_STRENGTHENING -> MemorizationState.STRENGTHENING
                MemorizationState.STRENGTHENING -> MemorizationState.REVIEWING
                else -> current
            }
            val repetition = if (current == MemorizationState.MEMORIZING) (_state.value.repetition + 1).coerceAtMost(3) else _state.value.repetition
            save(next, repetition)
            if (next == MemorizationState.STABLE) {
                planRepository.setTaskCompleted(taskId, true)
                db.goalDao().updateCurrentPage(pageEnd)
                if (startVerseKey.isNotBlank() && endVerseKey.isNotBlank()) {
                    db.memorizationSelectionDao().save(
                        ir.hefzyar.app.core.database.MemorizationSelectionEntity(
                            startVerseKey = startVerseKey,
                            endVerseKey = endVerseKey,
                            pageStart = pageStart,
                            pageEnd = pageEnd
                        )
                    )
                }
                RetentionScheduler.schedule(context, pageStart, pageEnd)
            }
        }
    }

    fun markRecallError() {
        viewModelScope.launch {
            val errors = _state.value.errors + 1
            val next = if (errors >= 3) MemorizationState.NEEDS_STRENGTHENING else _state.value.stage
            save(next, _state.value.repetition, errors)
        }
    }

    private suspend fun save(stage: MemorizationState, repetition: Int = _state.value.repetition, errors: Int = _state.value.errors) {
        val updated = MemorizationSessionEntity(
            id = session?.id ?: 0,
            planDate = today,
            pageStart = pageStart,
            pageEnd = pageEnd,
            stage = stage.name,
            repetition = repetition,
            errors = errors
        )
        if (updated.id == 0L) {
            val id = db.memorizationSessionDao().insert(updated)
            session = updated.copy(id = id)
        } else {
            db.memorizationSessionDao().update(updated)
            session = updated
        }
        _state.value = MemorizationUiState(stage, repetition, errors, stage == MemorizationState.STABLE)
    }
}

class MemorizationViewModelFactory(
    private val context: Context,
    private val pageStart: Int,
    private val pageEnd: Int,
    private val taskId: Long,
    private val startVerseKey: String = "",
    private val endVerseKey: String = ""
) : ViewModelProvider.Factory {
    @Suppress("UNCHECKED_CAST")
    override fun <T : ViewModel> create(modelClass: Class<T>): T =
        MemorizationViewModel(context.applicationContext, HefzyarDatabase.get(context), pageStart, pageEnd, taskId, startVerseKey, endVerseKey) as T
}
