package ir.hefzyar.app.feature.mushaf

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.clickable
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.SpanStyle
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import ir.hefzyar.app.domain.quran.MushafPageData
import ir.hefzyar.app.domain.quran.MushafWord

@Composable
fun RenderedMushafPage(
    data: MushafPageData,
    selectedVerseKeys: Set<String> = emptySet(),
    onVerseClick: ((String) -> Unit)? = null,
    dimmed: Boolean = false,
    hidden: Boolean = false,
    fontFamily: FontFamily = FontFamily.Default,
    modifier: Modifier = Modifier
) {
    Column(
        modifier = modifier
            .fillMaxWidth()
            .background(MaterialTheme.colorScheme.surface)
            .border(1.dp, MaterialTheme.colorScheme.outlineVariant, RoundedCornerShape(12.dp))
            .padding(horizontal = 18.dp, vertical = 14.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Text("${data.pageNumber}", style = MaterialTheme.typography.labelMedium)
        Spacer(Modifier.height(10.dp))
        if (hidden) {
            Box(Modifier.fillMaxWidth().height(420.dp), contentAlignment = Alignment.Center) {
                Text("صفحه مخفی است\nبازیابی را انجام بده", textAlign = TextAlign.Center)
            }
        } else {
            Column(
                modifier = Modifier.alpha(if (dimmed) 0.16f else 1f),
                verticalArrangement = Arrangement.spacedBy(8.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                data.lines.sortedBy { line -> line.firstOrNull()?.lineNumber ?: 0 }.forEach { line ->
                    LineText(line, selectedVerseKeys, fontFamily, onVerseClick)
                }
            }
        }
    }
}

@Composable
private fun LineText(words: List<MushafWord>, selectedVerseKeys: Set<String>, fontFamily: FontFamily, onVerseClick: ((String) -> Unit)?) {
    val builder = AnnotatedString.Builder()
    words.forEachIndexed { index, word ->
        if (index > 0) builder.append(" ")
        if (word.verseKey in selectedVerseKeys) {
            builder.pushStyle(
                SpanStyle(
                    background = MaterialTheme.colorScheme.primary.copy(alpha = 0.12f),
                    fontWeight = FontWeight.SemiBold
                )
            )
        }
        builder.append(word.textUthmani)
        if (word.verseKey in selectedVerseKeys) builder.pop()
    }
    Text(
        text = builder.toAnnotatedString(),
        fontFamily = fontFamily,
        fontSize = 21.sp,
        lineHeight = 34.sp,
        textAlign = TextAlign.Center,
        modifier = Modifier.fillMaxWidth().then(
            if (onVerseClick != null && words.isNotEmpty()) Modifier.clickable { onVerseClick(words.first().verseKey) } else Modifier
        )
    )
}
