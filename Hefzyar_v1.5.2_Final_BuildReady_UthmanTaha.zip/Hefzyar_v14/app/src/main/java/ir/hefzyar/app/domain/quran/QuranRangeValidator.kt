package ir.hefzyar.app.domain.quran

object QuranRangeValidator {
    fun isValid(range: QuranRange): Boolean {
        return when {
            range.start.surah < range.end.surah -> true
            range.start.surah > range.end.surah -> false
            else -> range.start.ayah <= range.end.ayah
        }
    }
}
