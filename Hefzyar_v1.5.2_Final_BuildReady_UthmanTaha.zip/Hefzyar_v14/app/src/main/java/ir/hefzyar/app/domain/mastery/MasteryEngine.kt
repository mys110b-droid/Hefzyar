package ir.hefzyar.app.domain.mastery

data class MasteryInput(
    val examScore: Double,
    val independentRecall: Double,
    val reviewSuccess: Double,
    val recentErrors: Double,
    val freshness: Double
)

class MasteryEngine {
    fun calculate(input: MasteryInput): Int {
        val score =
            input.examScore * .30 +
            input.independentRecall * .25 +
            input.reviewSuccess * .20 +
            input.freshness * .15 +
            (1.0 - input.recentErrors) * .10
        return (score.coerceIn(0.0, 1.0) * 100).toInt()
    }
}
