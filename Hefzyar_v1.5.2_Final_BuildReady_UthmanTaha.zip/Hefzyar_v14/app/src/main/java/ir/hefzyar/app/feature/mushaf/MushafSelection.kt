package ir.hefzyar.app.feature.mushaf

import ir.hefzyar.app.domain.quran.MushafWord

/** Touch-selection state for selecting an exact ayah range without inventing Quran data. */
data class MushafSelection(
    val startVerseKey: String? = null,
    val endVerseKey: String? = null
) {
    val isComplete: Boolean get() = !startVerseKey.isNullOrBlank() && !endVerseKey.isNullOrBlank()

    fun toggleVerse(verseKey: String): MushafSelection = when {
        startVerseKey == null -> copy(startVerseKey = verseKey, endVerseKey = verseKey)
        isComplete && startVerseKey == endVerseKey -> copy(endVerseKey = verseKey)
        else -> copy(endVerseKey = verseKey)
    }

    fun contains(verseKey: String, orderedVerseKeys: List<String>): Boolean {
        if (!isComplete) return false
        val start = orderedVerseKeys.indexOf(startVerseKey)
        val end = orderedVerseKeys.indexOf(endVerseKey)
        val idx = orderedVerseKeys.indexOf(verseKey)
        if (start < 0 || end < 0 || idx < 0) return false
        val lo = minOf(start, end); val hi = maxOf(start, end)
        return idx in lo..hi
    }
}

fun MushafWord.isSelectable(): Boolean = verseKey.isNotBlank()


fun MushafSelection.asEntity(page: Int): ir.hefzyar.app.core.database.MemorizationSelectionEntity? =
    if (!isComplete) null else ir.hefzyar.app.core.database.MemorizationSelectionEntity(
        startVerseKey = startVerseKey!!,
        endVerseKey = endVerseKey!!,
        pageStart = page,
        pageEnd = page
    )
