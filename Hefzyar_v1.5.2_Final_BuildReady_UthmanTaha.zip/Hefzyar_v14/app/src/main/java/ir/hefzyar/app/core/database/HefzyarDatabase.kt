package ir.hefzyar.app.core.database

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase

@Database(
    entities = [GoalEntity::class, DailyPlanEntity::class, TaskEntity::class, MemorizationSessionEntity::class, SurahEntity::class, AyahEntity::class, MushafPageEntity::class, MemorizationSelectionEntity::class],
    version = 5,
    exportSchema = false
)
abstract class HefzyarDatabase : RoomDatabase() {
    abstract fun goalDao(): GoalDao
    abstract fun dailyPlanDao(): DailyPlanDao
    abstract fun taskDao(): TaskDao
    abstract fun memorizationSessionDao(): MemorizationSessionDao
    abstract fun quranDao(): QuranDao
    abstract fun memorizationSelectionDao(): MemorizationSelectionDao

    companion object {
        @Volatile private var INSTANCE: HefzyarDatabase? = null

        fun get(context: Context): HefzyarDatabase =
            INSTANCE ?: synchronized(this) {
                INSTANCE ?: Room.databaseBuilder(
                    context.applicationContext,
                    HefzyarDatabase::class.java,
                    "hefzyar.db"
                )
                    .fallbackToDestructiveMigration()
                    .build()
                    .also { INSTANCE = it }
            }
    }
}
