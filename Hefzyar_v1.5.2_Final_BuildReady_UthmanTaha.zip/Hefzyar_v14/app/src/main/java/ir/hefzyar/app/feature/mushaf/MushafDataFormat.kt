package ir.hefzyar.app.feature.mushaf

/** Stable import contract for the verified Uthman Taha/Hafs page dataset. */
object MushafDataFormat {
    const val VERSION = 1
    const val REQUIRED_LINES_PER_PAGE = 15
    const val REQUIRED_PAGES = 604
    const val REQUIRED_NARRATION = "حفص عن عاصم"
    const val REQUIRED_CALLIGRAPHER = "عثمان طه"
}
