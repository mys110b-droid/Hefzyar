package ir.hefzyar.app.feature.mushaf

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.ui.platform.LocalContext
import kotlinx.coroutines.launch
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import ir.hefzyar.app.domain.quran.AyahRef
import ir.hefzyar.app.domain.quran.QuranRange
import ir.hefzyar.app.domain.quran.QuranRangeValidator
import ir.hefzyar.app.core.database.MemorizationSelectionEntity

@Composable
fun MushafScreen(onBack: () -> Unit, onStartMemorization: (MemorizationSelectionEntity) -> Unit) {
    var page by remember { mutableIntStateOf(1) }
    var eyeMode by remember { mutableStateOf(EyeRecallMode.FULL) }
    var startSurah by remember { mutableIntStateOf(1) }
    var startAyah by remember { mutableIntStateOf(1) }
    var endSurah by remember { mutableIntStateOf(1) }
    var endAyah by remember { mutableIntStateOf(1) }
    var selectedRange by remember { mutableStateOf<QuranRange?>(null) }
    var touchSelection by remember { mutableStateOf(MushafSelection()) }
    val scope = rememberCoroutineScope()
    val context = LocalContext.current
    val database = remember { ir.hefzyar.app.core.database.HefzyarDatabase.get(context) }
    var pageData by remember { mutableStateOf<ir.hefzyar.app.domain.quran.MushafPageData?>(null) }
    val repository: MushafDataRepository = remember { EmptyMushafDataRepository() }
    LaunchedEffect(page) { scope.launch { pageData = repository.page(page) } }
    val range = runCatching { QuranRange(AyahRef(startSurah, startAyah), AyahRef(endSurah, endAyah)) }.getOrNull()
    val valid = range?.let(QuranRangeValidator::isValid) == true

    Scaffold(topBar = { TopAppBar(title = { Text("مصحف") }, navigationIcon = { TextButton(onClick = onBack) { Text("بازگشت") } }) }) { p ->
        Column(
            Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(p).padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            MushafProfileCard()
            Text("موقعیت قرآن", style = MaterialTheme.typography.titleLarge)
            Text("صفحه، سوره و آیه سه شناسه مستقل برای یک محدوده حفظ هستند.", style = MaterialTheme.typography.bodyMedium)

            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedButton(onClick = { page = (page - 1).coerceAtLeast(1) }, Modifier.weight(1f)) { Text("صفحه قبل") }
                OutlinedButton(onClick = { page = (page + 1).coerceAtMost(604) }, Modifier.weight(1f)) { Text("صفحه بعد") }
            }
            pageData?.let { data ->
                RenderedMushafPage(
                    data = data,
                    selectedVerseKeys = data.verses.map { it.verseKey }.filter { touchSelection.contains(it, data.verses.map { v -> v.verseKey }) }.toSet(),
                    onVerseClick = { key -> touchSelection = touchSelection.toggleVerse(key) }
                )
            } ?: QuranPage(page)

            HorizontalDivider()
            Text("انتخاب محدوده آیات", style = MaterialTheme.typography.titleLarge)
            NumberField("سوره شروع", startSurah) { startSurah = it.coerceIn(1, 114) }
            NumberField("آیه شروع", startAyah) { startAyah = it.coerceAtLeast(1) }
            NumberField("سوره پایان", endSurah) { endSurah = it.coerceIn(1, 114) }
            NumberField("آیه پایان", endAyah) { endAyah = it.coerceAtLeast(1) }
            Button(
                onClick = { if (valid) selectedRange = range },
                enabled = valid,
                modifier = Modifier.fillMaxWidth()
            ) { Text("انتخاب محدوده") }

            selectedRange?.let {
                Card(Modifier.fillMaxWidth()) {
                    Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                        Text("محدوده انتخاب‌شده", style = MaterialTheme.typography.titleMedium)
                        Text("سوره ${it.start.surah}:${it.start.ayah} تا سوره ${it.end.surah}:${it.end.ayah}")
                    }
                }
            }

            HorizontalDivider()

            Card(Modifier.fillMaxWidth()) {
                Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text("انتخاب با لمس", style = MaterialTheme.typography.titleMedium)
                    Text(
                        if (touchSelection.isComplete) "از ${touchSelection.startVerseKey} تا ${touchSelection.endVerseKey}" else "برای شروع، محدوده آیه را روی صفحه انتخاب کن.",
                        style = MaterialTheme.typography.bodyMedium
                    )
                    if (touchSelection.isComplete) {
                        Button(
                            onClick = {
                                val selection = touchSelection.asEntity(page)
                                if (selection != null) {
                                    scope.launch {
                                        database.memorizationSelectionDao().save(selection)
                                        onStartMemorization(selection)
                                    }
                                }
                            },
                            Modifier.fillMaxWidth()
                        ) { Text("شروع حفظ این محدوده") }
                    }
                }
            }
            EyeRecallView(page, eyeMode, { eyeMode = it }, {}, Modifier.fillMaxWidth())
        }
    }
}

@Composable
private fun NumberField(label: String, value: Int, onValueChange: (Int) -> Unit) {
    OutlinedTextField(
        value = value.toString(),
        onValueChange = { input -> input.filter(Char::isDigit).toIntOrNull()?.let(onValueChange) },
        label = { Text(label) },
        singleLine = true,
        modifier = Modifier.fillMaxWidth()
    )
}
