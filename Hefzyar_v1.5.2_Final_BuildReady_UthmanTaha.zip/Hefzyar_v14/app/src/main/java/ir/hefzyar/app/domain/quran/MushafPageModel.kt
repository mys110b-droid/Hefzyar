package ir.hefzyar.app.domain.quran

/** Data required to render one 15-line Madinah Mushaf page. */
data class MushafWord(
    val verseKey: String,
    val position: Int,
    val textUthmani: String,
    val glyphCodeV2: String? = null,
    val lineNumber: Int
)

data class MushafVerse(
    val verseKey: String,
    val textUthmani: String,
    val lineStart: Int,
    val lineEnd: Int,
    val words: List<MushafWord> = emptyList()
)

data class MushafPageData(
    val pageNumber: Int,
    val lines: List<List<MushafWord>>,
    val verses: List<MushafVerse>
)
