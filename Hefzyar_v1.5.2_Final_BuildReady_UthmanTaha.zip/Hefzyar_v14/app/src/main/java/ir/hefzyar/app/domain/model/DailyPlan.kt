package ir.hefzyar.app.domain.model

enum class TaskType {
    LISTENING, MEMORIZATION, RETENTION, TEN_LESSON, CYCLE, STRENGTHENING, EXAM
}

data class DailyTask(
    val type: TaskType,
    val title: String,
    val description: String,
    val isCompleted: Boolean = false,
    val id: Long = 0L
)

data class DailyPlan(
    val date: String,
    val dayIndex: Int,
    val memorizationPageStart: Int?,
    val memorizationPageEnd: Int?,
    val tasks: List<DailyTask>
)
