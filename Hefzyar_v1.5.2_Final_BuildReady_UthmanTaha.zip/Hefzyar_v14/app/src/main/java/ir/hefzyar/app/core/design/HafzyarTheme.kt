package ir.hefzyar.app.core.design

import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

object HafzyarColors {
    val Green = Color(0xFF176B55)
    val DeepGreen = Color(0xFF0D4639)
    val Gold = Color(0xFFD2A84A)
    val Cream = Color(0xFFFAF8F1)
    val Charcoal = Color(0xFF202522)
}

private val LightColors = lightColorScheme(
    primary = HafzyarColors.Green,
    onPrimary = Color.White,
    secondary = HafzyarColors.Gold,
    background = HafzyarColors.Cream,
    surface = Color.White,
    onBackground = HafzyarColors.Charcoal,
    onSurface = HafzyarColors.Charcoal
)

@Composable
fun HafzyarTheme(content: @Composable () -> Unit) {
    MaterialTheme(colorScheme = LightColors, typography = Typography(), content = content)
}
