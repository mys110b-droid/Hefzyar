package ir.hefzyar.app.core.notifications

import android.app.NotificationChannel
import android.app.NotificationManager
import android.content.Context
import androidx.core.app.NotificationCompat
import androidx.work.CoroutineWorker
import androidx.work.WorkerParameters
import ir.hefzyar.app.R

class RetentionNotificationWorker(
    appContext: Context,
    params: WorkerParameters
) : CoroutineWorker(appContext, params) {
    override suspend fun doWork(): Result {
        NotificationChannels.ensure(applicationContext)
        val title = inputData.getString("title") ?: "وقت مرور حفظ جدید"
        val text = inputData.getString("text") ?: "بدون نگاه کردن به قرآن مرور کن."
        val notification = NotificationCompat.Builder(applicationContext, NotificationChannels.RETENTION)
            .setSmallIcon(android.R.drawable.ic_menu_agenda)
            .setContentTitle(title)
            .setContentText(text)
            .setPriority(NotificationCompat.PRIORITY_DEFAULT)
            .setAutoCancel(true)
            .build()
        applicationContext.getSystemService(NotificationManager::class.java)
            .notify(id.hashCode(), notification)
        return Result.success()
    }
}

object NotificationChannels {
    const val RETENTION = "retention"
    fun ensure(context: Context) {
        val manager = context.getSystemService(NotificationManager::class.java)
        manager.createNotificationChannel(
            NotificationChannel(
                RETENTION,
                "مرور و تثبیت",
                NotificationManager.IMPORTANCE_DEFAULT
            ).apply { description = "یادآوری مرورهای فاصله‌دار حفظیار" }
        )
    }
}
