package ir.hefzyar.app.domain.quran.importer

import androidx.room.withTransaction
import ir.hefzyar.app.core.database.AyahEntity
import ir.hefzyar.app.core.database.HefzyarDatabase
import ir.hefzyar.app.core.database.MushafPageEntity
import ir.hefzyar.app.core.database.SurahEntity
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

/**
 * Offline-first import boundary for verified Quran data.
 * The APK intentionally contains no Quran text in v0.9; a verified source package
 * is supplied separately and passed through this validator before insertion.
 */
class QuranImportPipeline(private val database: HefzyarDatabase) {
    suspend fun validateAndImport(
        sourceName: String,
        sourceVersion: String,
        surahs: List<SurahEntity>,
        rows: List<QuranImportAyah>
    ): QuranImportReport = withContext(Dispatchers.IO) {
        val errors = QuranImportValidator.validate(rows).toMutableList()
        if (surahs.size != 114) errors += "Expected 114 surahs, received ${surahs.size}."

        val surahNumbers = surahs.map { it.surahNumber }.toSet()
        rows.filter { it.surahNumber !in surahNumbers }
            .take(10)
            .forEach { errors += "Missing surah metadata for ${it.surahNumber}." }

        if (errors.isNotEmpty()) {
            return@withContext QuranImportReport(sourceName, sourceVersion, 0, 0, 0, errors)
        }

        val pages = rows.map { it.pageNumber }.distinct().map { MushafPageEntity(pageNumber = it) }
        val ayahs = rows.map {
            AyahEntity(
                surahNumber = it.surahNumber,
                ayahNumber = it.ayahNumber,
                pageNumber = it.pageNumber,
                juzNumber = it.juzNumber,
                hizbNumber = it.hizbNumber,
                text = it.text,
                textSource = "$sourceName@$sourceVersion"
            )
        }

        database.withTransaction {
            database.quranDao().clearAyahs()
            database.quranDao().clearSurahs()
            database.quranDao().clearPages()
            database.quranDao().insertSurahs(surahs)
            database.quranDao().insertAyahs(ayahs)
            database.quranDao().insertPages(pages)
        }

        QuranImportReport(sourceName, sourceVersion, ayahs.size, surahs.size, pages.size, emptyList())
    }
}
