package ir.hefzyar.app.navigation

object Routes {
    const val Splash = "splash"
    const val Onboarding = "onboarding"
    const val SetupGoal = "setup/goal"
    const val Home = "home"
    const val Mushaf = "mushaf"
    const val Memorization = "memorization"
    const val Review = "review"
    const val Exam = "exam"
    const val Progress = "progress"
}
