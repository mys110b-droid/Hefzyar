package ir.hefzyar.app.domain.quran

/**
 * The default Hafzyar mushaf profile: Madinah Mushaf, Hafs 'an Asim,
 * Uthman Taha calligraphy, 15 lines / 604 pages.
 *
 * The exact font/data package must be supplied from an authorized source;
 * this class intentionally does not embed an unverified Quran font.
 */
data class MushafProfile(
    val id: String,
    val titleFa: String,
    val calligrapher: String,
    val narration: String,
    val pages: Int,
    val linesPerPage: Int,
    val fontAssetPath: String?
)

object HafzyarMushafProfiles {
    val UTHMAN_TAHA_HAFS = MushafProfile(
        id = "madinah_uthman_taha_hafs_604",
        titleFa = "مصحف مدینه — رسم‌الخط عثمان طه",
        calligrapher = "عثمان طه",
        narration = "حفص عن عاصم",
        pages = 604,
        linesPerPage = 15,
        fontAssetPath = "quran/fonts/UthmanicHafs1_Ver09.ttf"
    )
}
