package ir.hefzyar.app.feature.mushaf

import ir.hefzyar.app.domain.quran.MushafPageData

/**
 * Local-first page provider. The real Uthman Taha/QCF page dataset can be
 * plugged in without changing the renderer or memorization flow.
 */
interface MushafDataRepository {
    suspend fun page(pageNumber: Int): MushafPageData?
}

class EmptyMushafDataRepository : MushafDataRepository {
    override suspend fun page(pageNumber: Int): MushafPageData? = null
}
