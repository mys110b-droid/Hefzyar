package ir.hefzyar.app.core.database

import androidx.room.*
import kotlinx.coroutines.flow.Flow

@Dao
interface GoalDao {
    @Query("SELECT * FROM goals WHERE id = 1 LIMIT 1")
    fun observeGoal(): Flow<GoalEntity?>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun save(goal: GoalEntity)

    @Query("UPDATE goals SET currentPage = :page WHERE id = 1")
    suspend fun updateCurrentPage(page: Int)

    @Query("DELETE FROM goals")
    suspend fun clear()
}

@Dao
interface DailyPlanDao {
    @Query("SELECT * FROM daily_plans ORDER BY planDate ASC")
    fun observePlans(): Flow<List<DailyPlanEntity>>

    @Query("SELECT * FROM daily_plans WHERE planDate = :date LIMIT 1")
    fun observePlan(date: String): Flow<DailyPlanEntity?>

    @Insert
    suspend fun insert(plan: DailyPlanEntity): Long

    @Insert
    suspend fun insertAll(plans: List<DailyPlanEntity>): List<Long>

    @Query("DELETE FROM daily_plans")
    suspend fun clear()
}

@Dao
interface TaskDao {
    @Query("SELECT * FROM tasks WHERE planId = :planId ORDER BY id")
    fun observeTasks(planId: Long): Flow<List<TaskEntity>>

    @Query("SELECT * FROM tasks WHERE planId IN (:planIds) ORDER BY id")
    fun observeTasksForPlans(planIds: List<Long>): Flow<List<TaskEntity>>

    @Insert
    suspend fun insertAll(tasks: List<TaskEntity>)

    @Query("SELECT * FROM tasks WHERE id = :taskId LIMIT 1")
    suspend fun getById(taskId: Long): TaskEntity?

    @Query("UPDATE tasks SET completed = :completed WHERE id = :taskId")
    suspend fun setCompleted(taskId: Long, completed: Boolean)

    @Query("DELETE FROM tasks")
    suspend fun clear()
}


@Dao
interface MemorizationSessionDao {
    @Query("SELECT * FROM memorization_sessions WHERE planDate = :planDate AND pageStart = :pageStart AND pageEnd = :pageEnd ORDER BY id DESC LIMIT 1")
    fun observe(planDate: String, pageStart: Int, pageEnd: Int): Flow<MemorizationSessionEntity?>

    @Insert
    suspend fun insert(session: MemorizationSessionEntity): Long

    @Update
    suspend fun update(session: MemorizationSessionEntity)
}

@Dao
interface QuranDao {
    @Query("SELECT * FROM quran_surahs ORDER BY surahNumber")
    fun observeSurahs(): Flow<List<SurahEntity>>

    @Query("SELECT * FROM quran_ayahs WHERE pageNumber = :page ORDER BY surahNumber, ayahNumber")
    fun observeAyahsOnPage(page: Int): Flow<List<AyahEntity>>

    @Query("SELECT * FROM quran_ayahs WHERE surahNumber = :surah ORDER BY ayahNumber")
    fun observeSurahAyahs(surah: Int): Flow<List<AyahEntity>>

    @Query("SELECT * FROM quran_ayahs WHERE surahNumber = :surah AND ayahNumber = :ayah LIMIT 1")
    suspend fun getAyah(surah: Int, ayah: Int): AyahEntity?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertSurahs(items: List<SurahEntity>)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertAyahs(items: List<AyahEntity>)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertPages(items: List<MushafPageEntity>)

    @Query("DELETE FROM quran_ayahs")
    suspend fun clearAyahs()

    @Query("DELETE FROM quran_surahs")
    suspend fun clearSurahs()

    @Query("DELETE FROM quran_pages")
    suspend fun clearPages()
}

@Dao
interface MemorizationSelectionDao {
    @Query("SELECT * FROM memorization_selections WHERE id = 1 LIMIT 1")
    fun observe(): Flow<MemorizationSelectionEntity?>

    @Query("SELECT * FROM memorization_selections WHERE id = 1 LIMIT 1")
    suspend fun get(): MemorizationSelectionEntity?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun save(selection: MemorizationSelectionEntity)

    @Query("DELETE FROM memorization_selections")
    suspend fun clear()
}
