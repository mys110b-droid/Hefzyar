package ir.hefzyar.app.domain.planning

import androidx.room.withTransaction
import ir.hefzyar.app.core.database.*
import kotlinx.coroutines.flow.Flow

class PlanRepository(private val db: HefzyarDatabase) {
    private val planDao = db.dailyPlanDao()
    private val taskDao = db.taskDao()

    fun observePlan(date: String): Flow<DailyPlanEntity?> = planDao.observePlan(date)
    fun observeTasks(planId: Long): Flow<List<TaskEntity>> = taskDao.observeTasks(planId)

    suspend fun replacePlans(plans: List<ir.hefzyar.app.domain.model.DailyPlan>) {
        db.withTransaction {
            taskDao.clear()
            planDao.clear()
            plans.forEach { plan ->
                val planId = planDao.insert(
                    DailyPlanEntity(
                        planDate = plan.date,
                        dayIndex = plan.dayIndex,
                        pageStart = plan.memorizationPageStart,
                        pageEnd = plan.memorizationPageEnd,
                        generatedAt = System.currentTimeMillis()
                    )
                )
                taskDao.insertAll(plan.tasks.map { task ->
                    TaskEntity(
                            planId = planId,
                            type = task.type.name,
                            title = task.title,
                            description = task.description,
                            completed = task.isCompleted
                        )
                })
            }
        }
    }

    suspend fun setTaskCompleted(taskId: Long, completed: Boolean) = taskDao.setCompleted(taskId, completed)
}
