package ir.hefzyar.app.domain.quran

data class AyahRef(val surah: Int, val ayah: Int)

data class QuranRange(
    val start: AyahRef,
    val end: AyahRef
) {
    init {
        require(start.surah in 1..114)
        require(end.surah in 1..114)
        require(start.ayah >= 1 && end.ayah >= 1)
    }
}

data class QuranPageRef(
    val page: Int,
    val start: AyahRef? = null,
    val end: AyahRef? = null,
    val juz: Int? = null,
    val hizb: Int? = null
)
