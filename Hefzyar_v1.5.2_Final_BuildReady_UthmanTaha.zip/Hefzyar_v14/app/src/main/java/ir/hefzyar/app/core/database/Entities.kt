package ir.hefzyar.app.core.database

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "goals")
data class GoalEntity(
    @PrimaryKey val id: Long = 1L,
    val totalPages: Int,
    val currentPage: Int,
    val pagesPerDay: Double,
    val targetName: String
)

@Entity(tableName = "daily_plans")
data class DailyPlanEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val planDate: String,
    val dayIndex: Int,
    val pageStart: Int?,
    val pageEnd: Int?,
    val generatedAt: Long
)

@Entity(tableName = "tasks")
data class TaskEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val planId: Long,
    val type: String,
    val title: String,
    val description: String,
    val completed: Boolean = false
)

@Entity(tableName = "memorization_sessions")
data class MemorizationSessionEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val planDate: String,
    val pageStart: Int,
    val pageEnd: Int,
    val stage: String,
    val repetition: Int = 0,
    val errors: Int = 0,
    val updatedAt: Long = System.currentTimeMillis()
)


@Entity(tableName = "memorization_selections")
data class MemorizationSelectionEntity(
    @PrimaryKey val id: Long = 1L,
    val startVerseKey: String,
    val endVerseKey: String,
    val pageStart: Int,
    val pageEnd: Int,
    val createdAt: Long = System.currentTimeMillis()
)
