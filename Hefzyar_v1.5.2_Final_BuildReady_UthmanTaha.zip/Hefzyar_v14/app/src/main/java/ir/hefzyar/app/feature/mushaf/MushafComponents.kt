package ir.hefzyar.app.feature.mushaf

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp

@Composable
fun QuranPage(
    pageNumber: Int,
    modifier: Modifier = Modifier,
    dimmed: Boolean = false,
    hidden: Boolean = false
) {
    val pageColor = MaterialTheme.colorScheme.surface
    Card(modifier = modifier, shape = RoundedCornerShape(18.dp), elevation = CardDefaults.cardElevation(2.dp)) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .background(pageColor)
                .padding(horizontal = 20.dp, vertical = 18.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Text("صفحه $pageNumber", style = MaterialTheme.typography.labelMedium)
            Spacer(Modifier.height(10.dp))
            if (hidden) {
                Box(Modifier.fillMaxWidth().height(300.dp), contentAlignment = Alignment.Center) {
                    Text("صفحه مخفی است\nبازیابی را انجام بده", textAlign = TextAlign.Center,
                        style = MaterialTheme.typography.titleMedium)
                }
            } else {
                Column(Modifier.alpha(if (dimmed) 0.16f else 1f), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    repeat(13) { index ->
                        // Placeholder geometry only. No Quranic text is invented here.
                        Box(Modifier.fillMaxWidth(if (index % 4 == 0) 0.78f else 0.94f).height(9.dp)
                            .border(1.dp, MaterialTheme.colorScheme.outline.copy(alpha = 0.28f), RoundedCornerShape(50)))
                    }
                }
            }
            Spacer(Modifier.height(12.dp))
            Text("منبع مصحف معتبر در مرحله تأمین داده افزوده خواهد شد.",
                style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant,
                textAlign = TextAlign.Center)
        }
    }
}

enum class EyeRecallMode { FULL, DIMMED, HIDDEN, REVEAL }

@Composable
fun EyeRecallView(
    pageNumber: Int,
    mode: EyeRecallMode,
    onModeChange: (EyeRecallMode) -> Unit,
    onResult: (Boolean) -> Unit,
    modifier: Modifier = Modifier
) {
    Column(modifier, verticalArrangement = Arrangement.spacedBy(12.dp)) {
        QuranPage(pageNumber = pageNumber, dimmed = mode == EyeRecallMode.DIMMED, hidden = mode == EyeRecallMode.HIDDEN)
        Text("چشم‌بری", style = MaterialTheme.typography.titleLarge)
        Text("بدون نگاه کردن به قرآن، محدوده را از حافظه بازیابی کن.", style = MaterialTheme.typography.bodyMedium)
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            listOf(EyeRecallMode.FULL to "کامل", EyeRecallMode.DIMMED to "کم‌رنگ", EyeRecallMode.HIDDEN to "مخفی").forEach { (value, label) ->
                FilterChip(selected = mode == value, onClick = { onModeChange(value) }, label = { Text(label) })
            }
        }
        if (mode == EyeRecallMode.HIDDEN || mode == EyeRecallMode.DIMMED) {
            Button(onClick = { onModeChange(EyeRecallMode.REVEAL) }, Modifier.fillMaxWidth()) { Text("نمایش پاسخ") }
        }
        if (mode == EyeRecallMode.REVEAL) {
            QuranPage(pageNumber = pageNumber)
            Text("چقدر مستقل بازیابی کردی؟", style = MaterialTheme.typography.titleMedium)
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedButton(onClick = { onResult(false) }, Modifier.weight(1f)) { Text("نیاز به مرور") }
                Button(onClick = { onResult(true) }, Modifier.weight(1f)) { Text("مسلط بودم") }
            }
        }
    }
}
