package ir.hefzyar.app.core.notifications

import android.content.Context
import androidx.work.OneTimeWorkRequestBuilder
import androidx.work.WorkManager
import androidx.work.workDataOf
import java.util.concurrent.TimeUnit

object RetentionScheduler {
    private const val TAG_PREFIX = "retention-"

    fun schedule(context: Context, pageStart: Int?, pageEnd: Int?) {
        if (pageStart == null || pageEnd == null) return
        val manager = WorkManager.getInstance(context)
        val ranges = listOf(
            15L to "مرور اول: صفحه $pageStart تا $pageEnd",
            30L to "مرور دوم: صفحه $pageStart تا $pageEnd",
            45L to "مرور سوم: صفحه $pageStart تا $pageEnd",
            60L to "مرور چهارم: صفحه $pageStart تا $pageEnd",
            90L to "مرور پنجم: صفحه $pageStart تا $pageEnd",
            120L to "مرور ششم: صفحه $pageStart تا $pageEnd",
            180L to "مرور تثبیتی: صفحه $pageStart تا $pageEnd"
        )
        ranges.forEachIndexed { index, (delay, title) ->
            val request = OneTimeWorkRequestBuilder<RetentionNotificationWorker>()
                .setInitialDelay(delay, TimeUnit.MINUTES)
                .setInputData(workDataOf(
                    "title" to title,
                    "text" to "بدون نگاه کردن به قرآن بازیابی کن."
                ))
                .addTag("$TAG_PREFIX$index")
                .build()
            manager.enqueue(request)
        }
    }
}
