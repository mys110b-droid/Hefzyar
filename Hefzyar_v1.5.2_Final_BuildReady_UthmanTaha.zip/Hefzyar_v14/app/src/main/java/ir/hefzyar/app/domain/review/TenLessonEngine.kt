package ir.hefzyar.app.domain.review

data class TenLessonItem(val lessonIndex: Int, val repetitions: Int)

class TenLessonEngine {
    fun build(): List<TenLessonItem> =
        (1..10).map { TenLessonItem(it, if (it <= 2) 3 else 2) }
}
