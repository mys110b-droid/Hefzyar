package ir.hefzyar.app.domain.model

data class Goal(
    val totalPages: Int = 604,
    val currentPage: Int = 0,
    val pagesPerMemorizationDay: Double = 1.0,
    val memorizationDays: Set<Int> = setOf(0, 1, 2, 3, 4, 5),
    val targetName: String = "حفظ کل قرآن"
)
