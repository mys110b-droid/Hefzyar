package ir.hefzyar.app.domain.planning

import java.time.Duration
import java.time.Instant

data class RetentionReview(
    val index: Int,
    val scheduledAt: Instant,
    val label: String
)

class RetentionScheduler {
    fun schedule(start: Instant): List<RetentionReview> = listOf(
        RetentionReview(1, start.plus(Duration.ofMinutes(15)), "مرور اول"),
        RetentionReview(2, start.plus(Duration.ofMinutes(30)), "مرور دوم"),
        RetentionReview(3, start.plus(Duration.ofMinutes(45)), "مرور سوم"),
        RetentionReview(4, start.plus(Duration.ofMinutes(60)), "مرور چهارم"),
        RetentionReview(5, start.plus(Duration.ofMinutes(90)), "مرور پنجم"),
        RetentionReview(6, start.plus(Duration.ofMinutes(120)), "مرور ششم"),
        RetentionReview(7, start.plus(Duration.ofHours(3)), "مرور ساعات بعد")
    )
}
