package ir.hefzyar.app.feature.mushaf

import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.Card
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import ir.hefzyar.app.domain.quran.HafzyarMushafProfiles

@Composable
fun MushafProfileCard(modifier: Modifier = Modifier) {
    val profile = HafzyarMushafProfiles.UTHMAN_TAHA_HAFS
    Card(modifier.fillMaxWidth()) {
        Column(Modifier.padding(16.dp)) {
            Text(profile.titleFa, style = MaterialTheme.typography.titleMedium)
            Text("خطاط: ${profile.calligrapher}", style = MaterialTheme.typography.bodyMedium)
            Text("روایت: ${profile.narration} • ${profile.linesPerPage} خط • ${profile.pages} صفحه", style = MaterialTheme.typography.bodySmall)
        }
    }
}
