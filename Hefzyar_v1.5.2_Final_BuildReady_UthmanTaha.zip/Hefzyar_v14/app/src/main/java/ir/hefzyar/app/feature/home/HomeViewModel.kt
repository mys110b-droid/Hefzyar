package ir.hefzyar.app.feature.home

import android.content.Context
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import ir.hefzyar.app.core.database.TaskEntity
import ir.hefzyar.app.core.notifications.RetentionScheduler
import ir.hefzyar.app.domain.model.Goal
import ir.hefzyar.app.domain.planning.PlanRepository
import ir.hefzyar.app.domain.repository.GoalRepository
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch
import java.time.LocalDate

data class HomeTaskUi(val id: Long, val type: String, val title: String, val description: String, val completed: Boolean)

data class HomeUiState(
    val loading: Boolean = true,
    val goal: Goal? = null,
    val todayTasks: List<HomeTaskUi> = emptyList(),
    val nextTask: HomeTaskUi? = null,
    val todayComplete: Boolean = false,
    val pageStart: Int? = null,
    val pageEnd: Int? = null
) {
    val progress: Float get() = goal?.let { if (it.totalPages == 0) 0f else it.currentPage.toFloat() / it.totalPages } ?: 0f
}

class HomeViewModel(
    private val appContext: Context,
    private val repository: GoalRepository,
    private val planRepository: PlanRepository
) : ViewModel() {
    private val today = LocalDate.now().toString()

    init {
        viewModelScope.launch {
            val goal = repository.observe().filterNotNull().first()
            if (planRepository.observePlan(today).first() == null) {
                planRepository.replacePlans(ir.hefzyar.app.domain.planning.PlanningEngine().generate(goal, LocalDate.now(), 7))
            }
        }
    }

    private val planFlow = planRepository.observePlan(today).flatMapLatest { plan ->
        if (plan == null) flowOf<Pair<ir.hefzyar.app.core.database.DailyPlanEntity?, List<ir.hefzyar.app.core.database.TaskEntity>>>(null to emptyList())
        else planRepository.observeTasks(plan.id).map { plan to it }
    }

    val uiState: StateFlow<HomeUiState> = combine(repository.observe(), planFlow) { goal, pair ->
        val (plan, tasks) = pair
        val uiTasks = tasks.map { it.toUi() }
        HomeUiState(
            loading = false,
            goal = goal,
            todayTasks = uiTasks,
            nextTask = uiTasks.firstOrNull { !it.completed },
            todayComplete = uiTasks.isNotEmpty() && uiTasks.all { it.completed },
            pageStart = plan?.pageStart,
            pageEnd = plan?.pageEnd
        )
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), HomeUiState())

    fun completeTask(taskId: Long) {
        viewModelScope.launch {
            val task = uiState.value.todayTasks.firstOrNull { it.id == taskId } ?: return@launch
            val completing = !task.completed
            planRepository.setTaskCompleted(taskId, completing)
            if (completing && task.type == "MEMORIZATION") {
                val endPage = uiState.value.pageEnd
                if (endPage != null) repository.updateCurrentPage(endPage)
                RetentionScheduler.schedule(appContext, uiState.value.pageStart, uiState.value.pageEnd)
            }
        }
    }

    private fun TaskEntity.toUi() = HomeTaskUi(id, type, title, description, completed)
}
