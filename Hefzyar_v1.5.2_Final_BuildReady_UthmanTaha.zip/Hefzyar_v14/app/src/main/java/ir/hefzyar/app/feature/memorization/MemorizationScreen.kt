package ir.hefzyar.app.feature.memorization

import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.lifecycle.viewmodel.compose.viewModel
import ir.hefzyar.app.domain.memorization.MemorizationState
import ir.hefzyar.app.feature.mushaf.EyeRecallMode
import ir.hefzyar.app.feature.mushaf.EyeRecallView
import ir.hefzyar.app.feature.mushaf.QuranPage

@Composable
fun MemorizationScreen(pageStart: Int, pageEnd: Int, taskId: Long, startVerseKey: String = "", endVerseKey: String = "", onFinished: () -> Unit, onBack: () -> Unit) {
    val context = androidx.compose.ui.platform.LocalContext.current
    val vm: MemorizationViewModel = viewModel(factory = MemorizationViewModelFactory(context, pageStart, pageEnd, taskId, startVerseKey, endVerseKey))
    val state by vm.state.collectAsState()
    var eyeMode by remember { mutableStateOf(EyeRecallMode.FULL) }
    val steps = listOf("آمادگی", "استماع", "حفظ", "اتصال", "تثبیت", "چشم‌بری", "تحویل")
    val index = when (state.stage) {
        MemorizationState.PREPARING -> 0
        MemorizationState.LISTENING -> 1
        MemorizationState.MEMORIZING -> 2
        MemorizationState.CONNECTION -> 3
        MemorizationState.RETENTION -> 4
        MemorizationState.REVIEWING, MemorizationState.STABLE -> 5
        else -> 0
    }
    Scaffold(topBar = { TopAppBar(title = { Text("حفظ جدید") }, navigationIcon = { TextButton(onClick = onBack) { Text("بازگشت") } }) }) { p ->
        Column(Modifier.fillMaxSize().padding(p).padding(20.dp), verticalArrangement = Arrangement.spacedBy(16.dp)) {
            Text("صفحه $pageStart تا $pageEnd", style = MaterialTheme.typography.titleMedium)
            if (startVerseKey.isNotBlank() && endVerseKey.isNotBlank()) {
                AssistChip(onClick = {}, label = { Text("محدوده: $startVerseKey تا $endVerseKey") })
            }
            LinearProgressIndicator(progress = { (index + 1) / steps.size.toFloat() }, modifier = Modifier.fillMaxWidth())
            Text(steps.joinToString("  •  "), style = MaterialTheme.typography.bodySmall)
            when (state.stage) {
                MemorizationState.MEMORIZING -> {
                    QuranPage(pageStart, Modifier.fillMaxWidth())
                    Text("تکرار: ${state.repetition} از ۳", style = MaterialTheme.typography.titleMedium)
                    Text(descriptionFor(state.stage, state.repetition))
                }
                MemorizationState.REVIEWING -> {
                    EyeRecallView(
                        pageNumber = pageStart,
                        mode = eyeMode,
                        onModeChange = { eyeMode = it },
                        onResult = { mastered -> if (mastered) vm.next() else vm.markRecallError() },
                        modifier = Modifier.fillMaxWidth()
                    )
                }
                else -> Card(Modifier.fillMaxWidth()) {
                    Column(Modifier.padding(20.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                        Text(titleFor(state.stage), style = MaterialTheme.typography.headlineSmall)
                        Text(descriptionFor(state.stage, state.repetition))
                        if (state.stage == MemorizationState.RETENTION) Text("پس از پایان حفظ، مرورهای فاصله‌دار برایت زمان‌بندی می‌شوند.")
                    }
                }
            }
            if (state.stage == MemorizationState.CONNECTION) {
                OutlinedButton(onClick = vm::markRecallError, modifier = Modifier.fillMaxWidth()) { Text("در بازیابی خطا داشتم") }
            }
            if (state.finished) {
                Button(onClick = onFinished, modifier = Modifier.fillMaxWidth().height(52.dp)) { Text("بازگشت به برنامه امروز") }
            } else {
                Button(onClick = vm::next, modifier = Modifier.fillMaxWidth().height(52.dp)) { Text(buttonFor(state.stage)) }
            }
        }
    }
}

private fun titleFor(s: MemorizationState) = when (s) {
    MemorizationState.PREPARING -> "آمادگی قبل از حفظ"
    MemorizationState.LISTENING -> "استماع قبل از حفظ"
    MemorizationState.MEMORIZING -> "حفظ و تکرار"
    MemorizationState.CONNECTION -> "اتصال آیات"
    MemorizationState.RETENTION -> "تثبیت اولیه"
    MemorizationState.REVIEWING -> "چشم‌بری و بازیابی"
    MemorizationState.STABLE -> "حفظ جدید ثبت شد 🌿"
    MemorizationState.NEEDS_STRENGTHENING -> "نیازمند تقویت"
    MemorizationState.STRENGTHENING -> "تقویت"
    else -> "حفظ جدید"
}

private fun descriptionFor(s: MemorizationState, repetition: Int) = when (s) {
    MemorizationState.PREPARING -> "معارف محدوده را مرور کن و برای حفظ آماده شو."
    MemorizationState.LISTENING -> "اکنون ترتیل محدوده جدید را بدون نگاه کردن به متن استماع کن."
    MemorizationState.MEMORIZING -> "آیه را به بخش‌های کوتاه تقسیم کن و هر آیه را سه بار مرور کن."
    MemorizationState.CONNECTION -> "آیه جدید را همراه با دو آیه قبل بازیابی کن."
    MemorizationState.RETENTION -> "حفظ جدید را بدون نگاه کردن مرور کن و برای تحویل آماده شو."
    MemorizationState.REVIEWING -> "چشم‌بری را انجام بده و سپس پاسخ را بررسی کن."
    MemorizationState.STABLE -> "این محدوده وارد چرخه تثبیت و مرور شد."
    MemorizationState.NEEDS_STRENGTHENING -> "خطاهای تکرارشونده ثبت شده‌اند؛ قبل از ادامه، محدوده را تقویت کن."
    MemorizationState.STRENGTHENING -> "روی بخش‌های خطادار تمرکز کن و دوباره بازیابی کن."
    else -> ""
}

private fun buttonFor(s: MemorizationState) = when (s) {
    MemorizationState.PREPARING -> "شروع استماع"
    MemorizationState.LISTENING -> "شروع حفظ"
    MemorizationState.MEMORIZING -> "ثبت تکرار"
    MemorizationState.CONNECTION -> "تأیید اتصال"
    MemorizationState.RETENTION -> "شروع چشم‌بری"
    MemorizationState.REVIEWING -> "ثبت تسلط"
    MemorizationState.NEEDS_STRENGTHENING -> "شروع تقویت"
    MemorizationState.STRENGTHENING -> "بازگشت به مرور"
    else -> "ادامه"
}
