package ir.hefzyar.app.feature.setup

import android.content.Context
import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import ir.hefzyar.app.core.database.HefzyarDatabase
import ir.hefzyar.app.domain.planning.PlanRepository
import ir.hefzyar.app.domain.repository.RoomGoalRepository

class GoalViewModelFactory(context: Context) : ViewModelProvider.Factory {
    private val db = HefzyarDatabase.get(context)
    private val goalRepository = RoomGoalRepository(db.goalDao())
    private val planRepository = PlanRepository(db)

    @Suppress("UNCHECKED_CAST")
    override fun <T : ViewModel> create(modelClass: Class<T>): T =
        if (modelClass.isAssignableFrom(GoalViewModel::class.java)) {
            GoalViewModel(goalRepository, planRepository) as T
        } else throw IllegalArgumentException("Unknown ViewModel")
}
