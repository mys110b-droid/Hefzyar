package ir.hefzyar.app.feature.splash

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import ir.hefzyar.app.core.design.HafzyarColors
import kotlinx.coroutines.delay

@Composable
fun SplashScreen(onFinished: () -> Unit) {
    LaunchedEffect(Unit) { delay(900); onFinished() }
    Box(Modifier.fillMaxSize().background(HafzyarColors.DeepGreen), contentAlignment = Alignment.Center) {
        Column(horizontalAlignment = Alignment.CenterHorizontally) {
            Text("حفظیار", color = Color.White, fontSize = 34.sp)
            Spacer(Modifier.height(8.dp))
            Text("یارِ راه حفظ قرآن", color = HafzyarColors.Gold, fontSize = 15.sp)
            Spacer(Modifier.height(24.dp))
            Text("السلام علیک یا تالی کتاب الله و ترجمانه", color = Color.White.copy(.82f), fontSize = 13.sp)
        }
    }
}
