package ir.hefzyar.app.domain.repository

import ir.hefzyar.app.core.database.GoalEntity
import ir.hefzyar.app.domain.model.Goal
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map

interface GoalRepository {
    fun observe(): Flow<Goal?>
    suspend fun save(goal: Goal)
    suspend fun updateCurrentPage(page: Int)
}

class RoomGoalRepository(
    private val dao: ir.hefzyar.app.core.database.GoalDao
) : GoalRepository {

    override fun observe(): Flow<Goal?> =
        dao.observeGoal().map { entity ->
            entity?.let {
                Goal(
                    totalPages = it.totalPages,
                    currentPage = it.currentPage,
                    pagesPerMemorizationDay = it.pagesPerDay,
                    targetName = it.targetName
                )
            }
        }

    override suspend fun updateCurrentPage(page: Int) {
        dao.updateCurrentPage(page)
    }

    override suspend fun save(goal: Goal) {
        dao.save(
            GoalEntity(
                totalPages = goal.totalPages,
                currentPage = goal.currentPage,
                pagesPerDay = goal.pagesPerMemorizationDay,
                targetName = goal.targetName
            )
        )
    }
}
