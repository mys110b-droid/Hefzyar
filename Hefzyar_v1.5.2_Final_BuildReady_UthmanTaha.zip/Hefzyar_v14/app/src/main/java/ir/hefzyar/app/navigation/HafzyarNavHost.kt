package ir.hefzyar.app.navigation

import androidx.compose.runtime.*
import androidx.navigation.compose.*
import androidx.navigation.NavType
import androidx.navigation.navArgument
import ir.hefzyar.app.feature.memorization.MemorizationScreen
import ir.hefzyar.app.feature.home.HomeScreen
import ir.hefzyar.app.feature.mushaf.MushafScreen
import ir.hefzyar.app.feature.onboarding.OnboardingScreen
import ir.hefzyar.app.feature.setup.GoalSetupScreen
import ir.hefzyar.app.feature.splash.SplashScreen

@Composable
fun HafzyarNavHost() {
    val navController = rememberNavController()

    NavHost(navController, startDestination = Routes.Splash) {
        composable(Routes.Splash) {
            SplashScreen {
                navController.navigate(Routes.Onboarding) {
                    popUpTo(Routes.Splash) { inclusive = true }
                }
            }
        }

        composable(Routes.Onboarding) {
            OnboardingScreen {
                navController.navigate(Routes.SetupGoal) {
                    popUpTo(Routes.Onboarding) { inclusive = true }
                }
            }
        }

        composable(Routes.SetupGoal) {
            GoalSetupScreen {
                navController.navigate(Routes.Home) {
                    popUpTo(Routes.SetupGoal) { inclusive = true }
                }
            }
        }

        composable(Routes.Home) {
            HomeScreen(
                onOpenMushaf = { navController.navigate(Routes.Mushaf) },
                onOpenMemorization = { taskId, start, end ->
                    navController.navigate("${Routes.Memorization}?taskId=$taskId&pageStart=$start&pageEnd=$end")
                }
            )
        }

        composable(
            route = "${Routes.Memorization}?taskId={taskId}&pageStart={pageStart}&pageEnd={pageEnd}&startKey={startKey}&endKey={endKey}",
            arguments = listOf(
                navArgument("taskId") { type = NavType.LongType },
                navArgument("pageStart") { type = NavType.IntType },
                navArgument("pageEnd") { type = NavType.IntType },
                navArgument("startKey") { type = NavType.StringType; defaultValue = "" },
                navArgument("endKey") { type = NavType.StringType; defaultValue = "" }
            )
        ) { entry ->
            val taskId = entry.arguments?.getLong("taskId") ?: 0L
            val start = entry.arguments?.getInt("pageStart") ?: 1
            val end = entry.arguments?.getInt("pageEnd") ?: start
            val startKey = entry.arguments?.getString("startKey").orEmpty()
            val endKey = entry.arguments?.getString("endKey").orEmpty()
            MemorizationScreen(
                pageStart = start,
                pageEnd = end,
                startVerseKey = startKey,
                endVerseKey = endKey,
                taskId = taskId,
                onFinished = { navController.popBackStack() },
                onBack = { navController.popBackStack() }
            )
        }

        composable(Routes.Mushaf) {
            MushafScreen(
                onBack = { navController.popBackStack() },
                onStartMemorization = { selection ->
                    navController.navigate(
                        "${Routes.Memorization}?taskId=0&pageStart=${selection.pageStart}&pageEnd=${selection.pageEnd}&startKey=${selection.startVerseKey}&endKey=${selection.endVerseKey}"
                    )
                }
            )
        }
    }
}
