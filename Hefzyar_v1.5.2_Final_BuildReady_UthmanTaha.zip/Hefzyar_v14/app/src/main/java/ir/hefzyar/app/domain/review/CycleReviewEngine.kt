package ir.hefzyar.app.domain.review

import kotlin.math.ceil

class CycleReviewEngine {
    fun dailyPages(totalMemorizedPages: Int): Int =
        if (totalMemorizedPages <= 0) 0 else ceil(totalMemorizedPages / 10.0).toInt()
}
