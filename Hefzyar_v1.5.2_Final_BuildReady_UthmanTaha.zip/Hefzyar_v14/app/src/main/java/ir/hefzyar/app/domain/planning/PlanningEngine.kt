package ir.hefzyar.app.domain.planning

import ir.hefzyar.app.domain.model.*
import java.time.LocalDate
import kotlin.math.ceil
import kotlin.math.floor

class PlanningEngine {
    fun estimatedMemorizationDays(goal: Goal): Int {
        val remaining = (goal.totalPages - goal.currentPage).coerceAtLeast(0)
        if (goal.pagesPerMemorizationDay <= 0.0 || goal.memorizationDays.isEmpty()) return 0
        val weeklyRatio = goal.memorizationDays.size / 7.0
        return ceil(remaining / goal.pagesPerMemorizationDay / weeklyRatio).toInt()
    }

    fun generate(goal: Goal, startDate: LocalDate = LocalDate.now(), numberOfDays: Int = 7): List<DailyPlan> {
        val plans = mutableListOf<DailyPlan>()
        var currentPage = goal.currentPage.toDouble()

        repeat(numberOfDays) { offset ->
            val date = startDate.plusDays(offset.toLong())
            val dayIndex = persianWeekIndex(date)
            val isMemorizationDay = dayIndex in goal.memorizationDays
            val tasks = mutableListOf<DailyTask>()
            var startPage: Int? = null
            var endPage: Int? = null

            if (isMemorizationDay && currentPage < goal.totalPages) {
                startPage = floor(currentPage).toInt() + 1
                endPage = minOf(goal.totalPages, floor(currentPage + goal.pagesPerMemorizationDay).toInt())
                tasks += DailyTask(TaskType.LISTENING, "استماع محدوده جدید", "محدوده امروز را پیش از حفظ و مطابق برنامه استماع کن.")
                tasks += DailyTask(TaskType.MEMORIZATION, "حفظ جدید", "صفحه $startPage تا $endPage را با روش حفظ تصویری حفظ کن.")
                tasks += DailyTask(TaskType.RETENTION, "تثبیت حفظ جدید", "مرورهای فاصله‌دار حفظ جدید امروز را انجام بده.")
                currentPage = endPage.toDouble()
            }

            tasks += DailyTask(TaskType.TEN_LESSON, "مرور ده‌درس", "دو درس اول را سه بار و هشت درس قدیمی‌تر را دو بار مرور کن.")
            tasks += DailyTask(TaskType.CYCLE, "مرور دوره", "یک‌دهم محفوظات را مطابق برنامه دوره مرور کن.")
            tasks += DailyTask(TaskType.EXAM, "آزمون کوتاه", "یک آزمون کوتاه از محدوده‌های امروز انجام بده.")

            plans += DailyPlan(date.toString(), dayIndex, startPage, endPage, tasks)
        }
        return plans
    }

    private fun persianWeekIndex(date: LocalDate): Int = when (date.dayOfWeek.value) {
        6 -> 0 // Saturday
        7 -> 1 // Sunday
        1 -> 2 // Monday
        2 -> 3 // Tuesday
        3 -> 4 // Wednesday
        4 -> 5 // Thursday
        else -> 6 // Friday
    }
}
