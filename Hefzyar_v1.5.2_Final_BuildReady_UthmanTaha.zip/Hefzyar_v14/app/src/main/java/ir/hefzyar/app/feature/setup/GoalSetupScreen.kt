package ir.hefzyar.app.feature.setup

import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.lifecycle.viewmodel.compose.viewModel
import ir.hefzyar.app.core.design.HafzyarColors
import ir.hefzyar.app.domain.model.Goal
import ir.hefzyar.app.domain.planning.PlanningEngine

@Composable
fun GoalSetupScreen(
    onComplete: () -> Unit
) {
    val context = androidx.compose.ui.platform.LocalContext.current
    val vm: GoalViewModel = viewModel(factory = GoalViewModelFactory(context))

    var currentPage by remember { mutableIntStateOf(0) }
    var pagesPerDay by remember { mutableFloatStateOf(1f) }
    val engine = remember { PlanningEngine() }

    val goal = Goal(
        currentPage = currentPage,
        pagesPerMemorizationDay = pagesPerDay.toDouble()
    )

    Column(Modifier.fillMaxSize().padding(24.dp)) {
        Text("هدف من", style = MaterialTheme.typography.headlineMedium)
        Spacer(Modifier.height(8.dp))
        Text("نقطه شروع و سرعت حفظت را مشخص کن.")

        Spacer(Modifier.height(28.dp))
        Text("صفحه فعلی: $currentPage")
        Slider(
            value = currentPage.toFloat(),
            onValueChange = { currentPage = it.toInt() },
            valueRange = 0f..604f
        )

        Spacer(Modifier.height(16.dp))
        Text("حفظ روزانه: ${"%.1f".format(pagesPerDay)} صفحه")
        Slider(
            value = pagesPerDay,
            onValueChange = { pagesPerDay = it },
            valueRange = .5f..3f,
            steps = 4
        )

        Spacer(Modifier.height(20.dp))
        Card(colors = CardDefaults.cardColors(containerColor = HafzyarColors.Cream)) {
            Column(Modifier.padding(20.dp)) {
                Text("پیش‌بینی اولیه")
                Spacer(Modifier.height(8.dp))
                Text(
                    "${engine.estimatedMemorizationDays(goal)} روز تقویمی",
                    style = MaterialTheme.typography.titleLarge
                )
                Text("این عدد با عملکرد واقعی تو تغییر می‌کند.")
            }
        }

        Spacer(Modifier.weight(1f))
        Button(
            onClick = { vm.save(goal, onComplete) },
            modifier = Modifier.fillMaxWidth().height(52.dp)
        ) {
            Text("ساخت برنامه من")
        }
    }
}
