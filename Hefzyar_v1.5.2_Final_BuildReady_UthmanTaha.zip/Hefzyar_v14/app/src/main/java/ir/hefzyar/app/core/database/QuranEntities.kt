package ir.hefzyar.app.core.database

import androidx.room.Entity
import androidx.room.Index

@Entity(tableName = "quran_surahs", indices = [Index(value = ["surahNumber"], unique = true)])
data class SurahEntity(
    @androidx.room.PrimaryKey val id: Long,
    val surahNumber: Int,
    val nameArabic: String,
    val namePersian: String? = null,
    val ayahCount: Int,
    val revelationType: String? = null
)

@Entity(tableName = "quran_ayahs", primaryKeys = ["surahNumber", "ayahNumber"], indices = [Index(value = ["pageNumber"]), Index(value = ["juzNumber"])])
data class AyahEntity(
    val surahNumber: Int,
    val ayahNumber: Int,
    val pageNumber: Int,
    val juzNumber: Int,
    val hizbNumber: Int? = null,
    val text: String? = null,
    val textSource: String? = null
)

@Entity(tableName = "quran_pages", indices = [Index(value = ["pageNumber"], unique = true)])
data class MushafPageEntity(
    @androidx.room.PrimaryKey val pageNumber: Int,
    val imageAsset: String? = null,
    val imageSource: String? = null
)
