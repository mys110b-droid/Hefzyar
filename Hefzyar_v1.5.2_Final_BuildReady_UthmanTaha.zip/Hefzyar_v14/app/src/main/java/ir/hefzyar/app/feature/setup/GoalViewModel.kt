package ir.hefzyar.app.feature.setup

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import ir.hefzyar.app.domain.model.Goal
import ir.hefzyar.app.domain.planning.PlanRepository
import ir.hefzyar.app.domain.planning.PlanningEngine
import ir.hefzyar.app.domain.repository.GoalRepository
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch
import java.time.LocalDate

class GoalViewModel(
    private val repository: GoalRepository,
    private val planRepository: PlanRepository
) : ViewModel() {
    val goal: StateFlow<Goal?> = repository.observe()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), null)

    fun save(goal: Goal, onSaved: () -> Unit) {
        viewModelScope.launch {
            repository.save(goal)
            val plans = PlanningEngine().generate(goal, LocalDate.now(), 7)
            planRepository.replacePlans(plans)
            onSaved()
        }
    }
}
