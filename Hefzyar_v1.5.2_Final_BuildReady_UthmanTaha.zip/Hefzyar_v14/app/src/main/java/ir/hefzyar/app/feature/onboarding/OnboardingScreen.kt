package ir.hefzyar.app.feature.onboarding

import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp

@Composable
fun OnboardingScreen(onContinue: () -> Unit) {
    Column(Modifier.fillMaxSize().padding(24.dp), verticalArrangement = Arrangement.Center) {
        Text("با برنامه حفظ کن", style = MaterialTheme.typography.headlineMedium)
        Spacer(Modifier.height(12.dp))
        Text("حفظیار برنامه حفظ، تثبیت، مرور و آزمون را بر اساس عملکرد واقعی تو مدیریت می‌کند.")
        Spacer(Modifier.height(12.dp))
        Text("همیشه قدم بعدی مسیر را می‌دانی.")
        Spacer(Modifier.height(32.dp))
        Button(onClick = onContinue, modifier = Modifier.fillMaxWidth().height(52.dp)) { Text("شروع مسیر") }
    }
}
