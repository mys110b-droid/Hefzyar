HEFZYAR QURAN DATA IMPORT

This directory is intentionally data-free in MVP v1.0.

Required before shipping Quran content:
1) Select one exact Mushaf layout and keep its ID fixed.
2) Obtain the Quran text from a verified source and preserve its license notice.
3) Record source name/version, script, Mushaf ID, page count and SHA-256 in import_manifest.json.
4) Validate all 114 surahs and 6,236 ayahs before inserting into Room.
5) Validate page/juz/hizb ranges against the selected Mushaf mapping.
6) Never silently normalize, edit, or rewrite Quran text during import.
7) Keep the original source and derived data traceable.

Tanzil licensing requires attribution, a link to tanzil.net, inclusion of the copyright notice,
and prohibits changing the text. Verify the current license before release.
