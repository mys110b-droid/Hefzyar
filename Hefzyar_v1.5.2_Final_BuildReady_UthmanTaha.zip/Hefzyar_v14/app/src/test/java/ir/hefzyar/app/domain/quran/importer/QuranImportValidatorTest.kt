package ir.hefzyar.app.domain.quran.importer

import org.junit.Assert.assertTrue
import org.junit.Test

class QuranImportValidatorTest {
    private val manifest = QuranSourceManifest(
        sourceName = "Test",
        sourceVersion = "1",
        script = "uthmani",
        mushafId = 4,
        pageCount = 604,
        license = "test",
        sourceUrl = "https://example.com",
        sha256 = "a".repeat(64)
    )

    @Test fun rejectsMissingRows() {
        val errors = QuranImportValidator.validate(emptyList(), manifest)
        assertTrue(errors.isNotEmpty())
    }

    @Test fun rejectsBadSha() {
        val bad = manifest.copy(sha256 = "bad")
        assertTrue(QuranImportValidator.validateManifest(bad).any { it.contains("SHA-256") })
    }
}
