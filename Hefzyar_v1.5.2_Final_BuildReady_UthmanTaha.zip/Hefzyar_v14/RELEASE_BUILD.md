# Hefzyar — Release Candidate Build

## Target
- Application ID: `ir.hefzyar.app`
- Version name: `1.5.0`
- Version code: `15`
- minSdk: 26
- targetSdk: 36
- Mushaf profile: QCF V2 / Hafs / Medina / 604 pages / 15 lines

## Important
This repository is a release-candidate Android project. It is **not accompanied by a prebuilt APK** because the current execution environment does not contain the Android SDK/Build Tools or a Gradle installation, so an APK cannot be honestly claimed as built and tested here.

## Before release
1. Open the project root in Android Studio.
2. Allow Gradle sync to download the declared Android/Compose/Room dependencies.
3. Provide the approved Quran dataset and QCF V2 page fonts according to the licensing/credit requirements of the chosen source.
4. Build and run the debug variant on a physical Android device.
5. Run unit/instrumentation tests.
6. Configure a private release signing key.
7. Build the signed release APK.

## Quran data
The app architecture separates:
- Unicode Uthmanic/Hafs text for search and fallback.
- QCF V2 `code_v2` + page number for pixel-accurate Mushaf rendering.

Do not ship placeholder or invented Quran text.

## Official technical references
Quran Foundation QCF rendering:
https://api-docs.quran.com/docs/tutorials/fonts/font-rendering/

Quran Foundation page layout:
https://api-docs.quran.com/docs/tutorials/fonts/page-layout/

Android release preparation:
https://developer.android.com/studio/publish/preparing

## Build verification note
The source tree has been dependency-audited for the declared Android toolchain. The current execution container does not provide Android SDK/Build Tools or a Gradle executable, so no APK is claimed as built here. Official AGP 9.4.0 compatibility requires Gradle 9.6.0 and SDK Build Tools 36.0.0; JDK 17 is the supported baseline.
