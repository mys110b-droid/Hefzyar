# Hefzyar MVP v1.4 — Uthman Taha

این نسخه انتخاب محدوده حفظ از روی مصحف را به جریان واقعی حفظ متصل می‌کند.

## تغییرات
- `MemorizationSelectionEntity` برای ذخیره محدوده انتخابی
- `MemorizationSelectionDao` و Room persistence
- انتخاب آیه شروع و پایان در Mushaf
- ذخیره فوری محدوده انتخابی قبل از ورود به Flow حفظ
- Navigation مستقیم از «شروع حفظ این محدوده» به Memorization Flow
- انتقال `startVerseKey` و `endVerseKey` به جلسه حفظ
- نمایش محدوده انتخاب‌شده در صفحه حفظ
- حفظ مشخصات مصحف Uthman Taha / Hafs / 604 pages در معماری موجود
- Database version 5

## وضعیت داده قرآن
این نسخه همچنان بدون متن قرآنی ساختگی ارائه می‌شود. Renderer برای Dataset واقعی عثمانی/حفص آماده است. برای نمایش دقیق صفحه، داده باید page-aware و line-aware باشد.

## مسیر کاربر
مصحف → لمس آیه شروع → لمس آیه پایان → ذخیره محدوده → شروع حفظ → استماع → حفظ → اتصال → چشم‌بری → ثبت تسلط

## منبع فنی
Quran Foundation documentation: page layout و word-level page/line metadata.

## Release candidate notes
- Added Android Material3 XML theme resource required by the manifest.
- Release build must be performed in an Android SDK/Gradle environment.
- No fabricated Quran dataset is bundled.
