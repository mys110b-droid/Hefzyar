# Hefzyar — Final Build Candidate

Product: حفظیار
Technical project: Hefzyar
Mushaf profile: Madinah / Hafs / QCF V2 architecture / 604 pages / 15 lines
Version: 1.5.0 (versionCode 15)

## Build
Open this project in a current Android Studio release and sync Gradle. Build the release variant from Build > Generate Signed Bundle / APK.

This environment does not contain Android SDK/Build Tools/Gradle distribution, so no APK was falsely claimed as built here.

## Quran data
The project intentionally does not ship fabricated Quran text. The production dataset must be imported from an approved source and verified before release. QCF V2 requires page-specific glyph fonts and code_v2/page_number mapping.
