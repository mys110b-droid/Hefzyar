# ساخت APK حفظیار

## محیط رسمی مورد انتظار
- Android Gradle Plugin 9.4.x
- Gradle 9.6.x
- JDK 17+
- Android SDK Platform 36
- Build Tools 36.0.0

AGP 9.4.0 طبق مستندات رسمی Android با Gradle 9.6.0 و Build Tools 36.0.0 سازگار است.

## Build محلی
پروژه را در Android Studio باز کنید و Gradle Sync را انجام دهید، سپس:

```bash
gradle test
gradle :app:assembleDebug
```

خروجی:

`app/build/outputs/apk/debug/app-debug.apk`

## Release
برای انتشار واقعی، کلید خصوصی release را خارج از مخزن نگه دارید و signing را در محیط CI/Android Studio تنظیم کنید. سپس:

```bash
gradle :app:assembleRelease
```

## CI
فایل `.github/workflows/android-build.yml` یک build خودکار Debug ایجاد می‌کند.

## داده قرآن
قبل از انتشار، Dataset مجاز و تأییدشده‌ی قرآن و QCF V2 باید در `app/src/main/assets/quran/` قرار گیرد. Placeholder یا متن ساختگی قرآن نباید منتشر شود.
