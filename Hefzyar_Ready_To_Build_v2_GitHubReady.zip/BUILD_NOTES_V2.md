# Hefzyar Build-Ready v2

This package fixes the compile blockers found in GitHub Actions:

- `MemorizationFlow`: added the missing `LISTENING` branch.
- `QuranImportValidator`: removed fragile destructuring in the duplicate-key check.
- `QuranImportValidator`: added the `validate(rows)` overload used by the import pipeline.
- `QuranImportPipeline`: now resolves against the validator API.
- KSP updated from the invalid `2.4.10-2.0.2` coordinate to `2.3.10`.
- Kotlin `kotlinOptions` migrated to `compilerOptions`.
- `compileSdk` / `targetSdk` set to 37.

Important: this package intentionally does **not** contain Quran text data. The verified Quran dataset must be supplied through the import boundary described in the project.
