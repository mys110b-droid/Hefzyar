// Release toolchain: AGP 9.4.x requires Gradle 9.6.x and JDK 17+; Android Studio can provision the declared Gradle wrapper.
plugins {
    id("com.android.application") version "9.4.0" apply false
    id("org.jetbrains.kotlin.plugin.compose") version "2.4.10" apply false
    id("com.google.devtools.ksp") version "2.3.10" apply false
}
