package ir.hefzyar.app.domain.memorization

class MemorizationFlow {
    fun next(
        current: MemorizationState,
        repeatedErrors: Int = 0
    ): MemorizationState {
        if (repeatedErrors >= 3) return MemorizationState.NEEDS_STRENGTHENING
        return when (current) {
            MemorizationState.NOT_STARTED -> MemorizationState.PREPARING
            MemorizationState.PREPARING -> MemorizationState.LISTENING
            MemorizationState.LISTENING -> MemorizationState.MEMORIZING
            MemorizationState.MEMORIZING -> MemorizationState.CONNECTION
            MemorizationState.CONNECTION -> MemorizationState.RETENTION
            MemorizationState.RETENTION -> MemorizationState.REVIEWING
            MemorizationState.REVIEWING -> MemorizationState.STABLE
            MemorizationState.NEEDS_STRENGTHENING -> MemorizationState.STRENGTHENING
            MemorizationState.STRENGTHENING -> MemorizationState.REVIEWING
            MemorizationState.STABLE -> MemorizationState.STABLE
        }
    }
}
