package ir.hefzyar.app.domain.quran.importer

/** Strict structural validation before Quran data is allowed into Room. */
object QuranImportValidator {
    // Standard Hafs/Madani verse counts used as a structural checksum.
    private val expectedAyahCounts = intArrayOf(
        7,286,200,176,120,165,206,75,129,109,123,111,43,52,99,128,111,110,98,135,
        112,78,118,64,77,227,93,88,69,60,34,30,73,54,45,83,182,88,75,85,54,53,89,59,
        37,35,38,29,18,45,60,49,62,55,78,96,29,22,24,13,14,11,11,18,12,12,30,52,52,
        44,28,28,20,56,40,31,50,40,46,42,29,19,36,25,22,17,19,26,30,20,15,21,11,8,
        8,11,19,5,8,8,11,11,8,3,9,5,4,7,3,6,3,5,4,5,6,3,5,4,5,6
    )

    fun validateManifest(manifest: QuranSourceManifest): List<String> = buildList {
        if (manifest.sourceName.isBlank()) add("Source name is required.")
        if (manifest.sourceVersion.isBlank()) add("Source version is required.")
        if (manifest.script.isBlank()) add("Quran script is required.")
        if (manifest.pageCount <= 0) add("Page count must be positive.")
        if (manifest.license.isBlank()) add("License information is required.")
        if (manifest.sourceUrl.isBlank()) add("Source URL is required.")
        if (!manifest.sha256.matches(Regex("[A-Fa-f0-9]{64}"))) add("SHA-256 must be a 64-character hexadecimal digest.")
    }

    /**
     * Structural validation for the standard 604-page Madani/Hafs mapping.
     * This overload is used by the import pipeline when source metadata is
     * supplied separately.
     */
    fun validate(rows: List<QuranImportAyah>): List<String> =
        validateRows(rows, 604)

    fun validate(rows: List<QuranImportAyah>, manifest: QuranSourceManifest): List<String> {
        val errors = validateManifest(manifest).toMutableList()
        if (manifest.pageCount != 604) {
            errors += "This MVP expects a 604-page Madani mapping; received ${manifest.pageCount}."
        }
        errors += validateRows(rows, manifest.pageCount)
        return errors.distinct()
    }

    private fun validateRows(rows: List<QuranImportAyah>, maxPage: Int): List<String> {
        val errors = mutableListOf<String>()
        if (rows.isEmpty()) return listOf("No Quran rows were provided.")

        rows.forEachIndexed { index, row ->
            if (row.surahNumber !in 1..114) {
                errors += "Row ${index + 1}: invalid surah number ${row.surahNumber}."
            }
            if (row.ayahNumber < 1) {
                errors += "Row ${index + 1}: ayah number must be positive."
            }
            if (row.surahNumber in 1..114 &&
                row.ayahNumber > expectedAyahCounts[row.surahNumber - 1]
            ) {
                errors += "Row ${index + 1}: ayah ${row.surahNumber}:${row.ayahNumber} exceeds expected surah count."
            }
            if (row.pageNumber !in 1..maxPage) {
                errors += "Row ${index + 1}: invalid page ${row.pageNumber}."
            }
            if (row.juzNumber !in 1..30) {
                errors += "Row ${index + 1}: invalid juz ${row.juzNumber}."
            }
            if (row.hizbNumber != null && row.hizbNumber !in 1..60) {
                errors += "Row ${index + 1}: invalid hizb ${row.hizbNumber}."
            }
            if (row.text.isBlank()) {
                errors += "Row ${index + 1}: Quran text is empty."
            }
        }

        // Avoid destructuring here so the validator remains compiler-friendly
        // across Kotlin 2.3/2.4 inference changes.
        rows.groupBy { it.surahNumber to it.ayahNumber }.forEach { entry ->
            val key = entry.key
            val values = entry.value
            if (values.size > 1) {
                errors += "Duplicate ayah key ${key.first}:${key.second}."
            }
        }

        val counts = rows.groupingBy { it.surahNumber }.eachCount()
        if (counts.size != 114) {
            errors += "Expected all 114 surahs; found ${counts.size}."
        }
        expectedAyahCounts.forEachIndexed { index, expected ->
            val actual = counts[index + 1] ?: 0
            if (actual != expected) {
                errors += "Surah ${index + 1}: expected $expected ayahs, found $actual."
            }
        }
        if (rows.size != expectedAyahCounts.sum()) {
            errors += "Expected ${expectedAyahCounts.sum()} ayahs, found ${rows.size}."
        }
        return errors.distinct()
    }

}
