package ir.hefzyar.app.feature.home

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.viewmodel.compose.viewModel
import ir.hefzyar.app.core.design.HafzyarColors

@Composable
fun HomeScreen(onOpenMushaf: () -> Unit, onOpenMemorization: (Long, Int, Int) -> Unit) {
    val context = androidx.compose.ui.platform.LocalContext.current
    val vm: HomeViewModel = viewModel(factory = HomeViewModelFactory(context))
    val state by vm.uiState.collectAsState()

    Scaffold(
        bottomBar = {
            NavigationBar {
                NavigationBarItem(true, {}, icon = { Icon(Icons.Outlined.Home, null) }, label = { Text("خانه") })
                NavigationBarItem(false, {}, icon = { Icon(Icons.Outlined.Book, null) }, label = { Text("حفظ") })
                NavigationBarItem(false, {}, icon = { Icon(Icons.Outlined.TaskAlt, null) }, label = { Text("مرور") })
                NavigationBarItem(false, {}, icon = { Icon(Icons.Outlined.PlayArrow, null) }, label = { Text("آزمون") })
                NavigationBarItem(false, {}, icon = { Icon(Icons.Outlined.TrendingUp, null) }, label = { Text("پیشرفت") })
            }
        }
    ) { padding ->
        LazyColumn(
            Modifier.fillMaxSize().padding(padding).padding(horizontal = 20.dp),
            contentPadding = PaddingValues(vertical = 24.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            item {
                Text("السلام علیک یا تالی کتاب الله و ترجمانه", color = HafzyarColors.Green, fontSize = 13.sp)
                Spacer(Modifier.height(12.dp))
                Text("سلام 🌿", fontSize = 28.sp)
            }

            item {
                Card(
                    shape = RoundedCornerShape(20.dp),
                    colors = CardDefaults.cardColors(containerColor = HafzyarColors.DeepGreen),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(Modifier.padding(24.dp)) {
                        Text("مسیر من", color = HafzyarColors.Gold)
                        Spacer(Modifier.height(8.dp))
                        Text("${(state.progress * 100).toInt()}٪", color = MaterialTheme.colorScheme.onPrimary, fontSize = 36.sp)
                        Text("${state.goal?.currentPage ?: 0} از ${state.goal?.totalPages ?: 604} صفحه", color = MaterialTheme.colorScheme.onPrimary.copy(.8f))
                    }
                }
            }

            item {
                Card(shape = RoundedCornerShape(20.dp), modifier = Modifier.fillMaxWidth()) {
                    Column(Modifier.padding(20.dp)) {
                        Text("قدم بعدی تو", color = HafzyarColors.Green)
                        Spacer(Modifier.height(8.dp))
                        if (state.todayComplete) {
                            Text("امروزت کامل شد 🌿", fontSize = 20.sp)
                            Text("تمام کارهای برنامه امروز انجام شده است.")
                        } else {
                            val task = state.nextTask
                            val pageStart = state.pageStart
                            val pageEnd = state.pageEnd
                            if (task != null) {
                                Text(task.title, fontSize = 20.sp)
                                Text(task.description)
                                Spacer(Modifier.height(16.dp))
                                Button(onClick = {
                                    if (task.type == "MEMORIZATION" && pageStart != null && pageEnd != null) {
                                        onOpenMemorization(task.id, pageStart, pageEnd)
                                    } else {
                                        vm.completeTask(task.id)
                                    }
                                }, modifier = Modifier.fillMaxWidth()) {
                                    Text(if (task.type == "MEMORIZATION") "شروع حفظ" else "انجام شد")
                                }
                            } else {
                                Text("برنامه امروز آماده نیست", fontSize = 20.sp)
                            }
                        }
                    }
                }
            }

            item { Text("برنامه امروز", fontSize = 18.sp) }

            if (state.todayTasks.isEmpty()) {
                item { Text("برای امروز هنوز برنامه‌ای ثبت نشده است.") }
            } else {
                items(state.todayTasks, key = { it.id }) { task ->
                    Card(shape = RoundedCornerShape(16.dp), modifier = Modifier.fillMaxWidth()) {
                        ListItem(
                            headlineContent = { Text(task.title) },
                            supportingContent = { Text(task.description, maxLines = 2) },
                            leadingContent = { Text(if (task.completed) "✓" else "○", color = HafzyarColors.Green, fontSize = 20.sp) },
                            trailingContent = {
                                TextButton(onClick = { vm.completeTask(task.id) }) {
                                    Text(if (task.completed) "برگردان" else "انجام شد")
                                }
                            }
                        )
                    }
                }
            }

            item {
                OutlinedButton(onClick = onOpenMushaf, modifier = Modifier.fillMaxWidth()) {
                    Icon(Icons.Outlined.MenuBook, null)
                    Spacer(Modifier.width(8.dp))
                    Text("باز کردن مصحف")
                }
            }
        }
    }
}
