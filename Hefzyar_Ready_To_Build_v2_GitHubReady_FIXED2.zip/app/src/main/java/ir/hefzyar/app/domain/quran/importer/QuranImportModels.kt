package ir.hefzyar.app.domain.quran.importer

/** Models used at the verified Quran-data import boundary. */
data class QuranImportAyah(
    val surahNumber: Int,
    val ayahNumber: Int,
    val pageNumber: Int,
    val juzNumber: Int,
    val hizbNumber: Int?,
    val text: String
)

data class QuranSourceManifest(
    val sourceName: String,
    val sourceVersion: String,
    val script: String,
    val mushafId: Int,
    val pageCount: Int,
    val license: String,
    val sourceUrl: String,
    val sha256: String
)

data class QuranImportReport(
    val sourceName: String,
    val sourceVersion: String,
    val importedAyahs: Int,
    val importedSurahs: Int,
    val importedPages: Int,
    val errors: List<String>
) {
    val isValid: Boolean get() = errors.isEmpty()
}
